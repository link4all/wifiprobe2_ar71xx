#ifndef GLOBAL_H
#define GLOBAL_H

extern char token[128];
extern char gmac[64];

#endif
